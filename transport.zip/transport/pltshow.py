import matplotlib.pyplot as plt
from matplotlib import rc
rc('text', usetex=False)
plt.plot([1,2],[2,3])
plt.show()
